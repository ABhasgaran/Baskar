const mongoose = require('mongoose');
const schema = mongoose.Schema;
EmpSchema = new Schema({
    name: String,
    sal: Number,
    age: Number
});

module.exports =  mongoose.model('employee', EmpSchema);