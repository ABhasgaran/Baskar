﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Core1Angular2CRUDTest.Models
{
    public class StudentMasters
    {

        [Key]
        public int stdID { get; set; }

        [Required]
        [Display(Name = "Name")]
        public string stdName { get; set; }

        [Required]
        [Display(Name = "Email")]
        public string email { get; set; }

        [Required]
        [Display(Name = "Phone")]
        public string phone { get; set; }

        public string address { get; set; }
    }
}
