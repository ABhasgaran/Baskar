﻿export class StudentMasters {
    constructor(
        public stdID: number,
        public stdName: string,
        public email: string,
        public phone: string,
        public address: string
    ) { }
}
