"use strict";
var StudentMasters = (function () {
    function StudentMasters(stdID, stdName, email, phone, address) {
        this.stdID = stdID;
        this.stdName = stdName;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }
    return StudentMasters;
}());
exports.StudentMasters = StudentMasters;
//# sourceMappingURL=model.js.map