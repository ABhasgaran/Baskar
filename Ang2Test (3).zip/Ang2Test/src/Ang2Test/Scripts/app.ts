﻿
import { Component, Injectable, Inject} from 'angular2/core';
import { NgIf, NgFor } from 'angular2/common';
import {Http, Response, HTTP_PROVIDERS, Headers, RequestOptions} from 'angular2/http';
import { StudentMasters } from './model';
import {Observable} from 'rxjs/Observable';
import 'rxjs/Rx';

@Component({
    selector: "my-app",
    directives: [NgFor],
    template: `     
<table style="background-color:#FFFFFF;padding :5px;width :99%;table-layout:fixed;" cellpadding="2" cellspacing="2">
                    <tr style="height: 30px; background-color:#336699 ; color:#FFFFFF ;border: solid 1px #659EC7;">
                    
                  <td>
                      <h2>Insert User Details</h2>
                  </td>
            </tr>
        <tr>
        <td>
 <table style="color:#9F000F;font-size:large" cellpadding="4" cellspacing="6">
 <tr>
     <td><b>User ID: </b> </td>
    <td>
      <input  [(ngModel)]="students.stdID" value="0" style="background-color:tan" readonly>
  </td>
  <td><b>User Name: </b> </td>
    <td>
    <input  [(ngModel)]="students.stdName" >
  </td>
</tr>
 <tr>
     <td><b>Email: </b> </td>
    <td>
      <input  [(ngModel)]="students.email" >
  </td>
  <td><b>Phone: </b> </td>
    <td>
    <input  [(ngModel)]="students.phone" >
  </td>
</tr>
<tr>
     <td><b>Location: </b> </td>
    <td>
     <input  [(ngModel)]="students.address" >
  </td>
  <td colspan="2">
<button (click)=addStudentsDetails() style="background-colorwhitesmoke;color:#FFFFFF;font-size:large;width:200px;
                              border-color:#a2aabe;border-width:2px;">Save</button>
   </td>
   </tr>
   </table>
 </td>
</tr>

<tr><td>&nbsp; </td></tr>

 <tr>
        <td>
 <table style="background-color:#FFFFFF; border solid 2px #6D7B8D; padding 5px;width 99%;table-layout:fixed;" cellpadding="2" cellspacing="2">

                                <tr style="height: 30px; background-color:#336699 ; color:#FFFFFF ;border: solid 1px #659EC7;">
                                    <td width="100" align="center">User ID</td>
                                    <td width="240" align="center">User Name</td>
                                    <td width="240" align="center">Email</td>
                                    <td width="120" align="center">Phone</td>
                                    <td width="340" align="center">Location</td>
                                    

                                </tr>
                                <tbody *ngFor="let std of student">
                                    <tr>

                                        <td align="center" style="border: solid 1px #659EC7; padding: 5px;table-layout:fixed;">
                                            <span style="color:#9F000F">{{std.stdID}}</span>
                                        </td>

                                        <td align="left" style="border: solid 1px #659EC7; padding: 5px;table-layout:fixed;">
                                            <span style="color:#9F000F">{{std.stdName}}</span>
                                        </td>

                                        <td align="left" style="border: solid 1px #659EC7; padding: 5px;table-layout:fixed;">
                                            <span style="color:#9F000F">{{std.email}}</span>
                                        </td>

                                        <td align="center" style="border: solid 1px #659EC7; padding: 5px;table-layout:fixed;">
                                            <span style="color:#9F000F">{{std.phone}}</span>
                                        </td>

                                        <td align="left" style="border: solid 1px #659EC7; padding: 5px;table-layout:fixed;">
                                            <span style="color:#9F000F">{{std.address}}</span>
                                        </td>
                                      
                                    </tr>
                                </tbody>
                            </table>
</td>
</tr>
</table>
              `,

})
export class AppComponent {
    student: Array<StudentMasters> = []; 
    students = {};
    myName: string;  
    constructor(@Inject(Http) public http: Http) {
        this.myName = "Test";      
        this.getData();       
    }

    getData() {         
        this.http.get('api/StudentMastersAPI')
            .map((responseData) => {
                return responseData.json();
            })
            .map((student: Array<any>) => {
                let result: Array<StudentMasters> = [];
                if (student) {
                    student.forEach((student) => {
                        result.push(new StudentMasters(student.stdID, student.stdName,
                            student.email, student.phone, student.address));
                    });
                }
                return result;
            }) 
            .subscribe(res => this.student = res);
    }

    addStudentsDetails() {     
        var headers = new Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        this.http.post('api/StudentMastersAPI', JSON.stringify(this.students), { headers: headers }).subscribe();
        alert("User Detail Inserted");
        this.getData();       
    }

    
}
