﻿// app.js
var routerApp = angular.module('routerApp', ['ui.router']);
routerApp.run(function ($rootScope, $state, AuthService) {
    $rootScope.$on("$stateChangeStart", function(event, toState, toParams, fromState, fromParams){
        if (toState.authenticate && !AuthService.IsAuthenticated()) {
            alert("Not Authenticated");
            // User isn’t authenticated
            $state.transitionTo("login");
            event.preventDefault(); 
        }
    });
});
routerApp.config(function ($stateProvider, $urlRouterProvider) {
    $stateProvider
        // HOME STATES AND NESTED VIEWS ========================================
        .state('home', {


            url: '/home',
            templateUrl: 'partials/partial-home.html',
            authenticate: true
        })
        .state("login", {
            url: "/login",
            templateUrl: "partials/login.html",
            controller: "myLoggingCtrl",
            authenticate: false
        })
        // ABOUT PAGE AND MULTIPLE NAMED VIEWS =================================
        .state('about', {
            // we'll get to this in a bit  
            url: '/about',
            templateUrl: 'partials/partial-about.html',
            authenticate: true
        });
    //If know route matches it will works........
    $urlRouterProvider.otherwise("/login");
});

routerApp.controller("myLoggingCtrl", function ($scope, $http, $state, AuthService) {
    $scope.myFunc = function (Users) {
        console.log(Users);
        //var promisePost = crudService.post(Users);
        return $http({
            method: 'POST',
            dataType: 'json',
            headers: {
                "Content-Type": "application/json"
            },
            url: 'http://localhost:60099/api/jwt',
            data: JSON.stringify(Users),
        }).success(function (data) {
            AuthService._isAuthenticated = true;
            AuthService._isAccessToken = data.access_token;
            console.log(AuthService);
            $state.go("home");
        });
        console.log(promisePost);
    }
});

routerApp.service('AuthService', function () {
    this._isAuthenticated = false;
    this._isAccessToken = '';
    this.IsAuthenticated = function () {
        return this._isAuthenticated;
    }
});