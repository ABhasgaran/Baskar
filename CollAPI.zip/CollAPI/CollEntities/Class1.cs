﻿using System;

namespace CollEntities
{
    public class Class1
    {
    }
}
