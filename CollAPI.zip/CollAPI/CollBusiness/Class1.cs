﻿using System;

namespace CollBusiness
{
    public class Class1
    {
    }
}
