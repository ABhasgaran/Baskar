﻿using System;

namespace CollRepositoryInterface
{
    public class Class1
    {
    }
}
