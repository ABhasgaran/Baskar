package com.vcmcred.apps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VcmcredApplication {

	public static void main(String[] args) {
		SpringApplication.run(VcmcredApplication.class, args);
	}
}
