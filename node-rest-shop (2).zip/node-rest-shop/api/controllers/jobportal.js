const mongoose = require('mongoose');
const Jobportal =require("../models/jobportal");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcrypt");

exports.jobportal_get_all = (req, res, next) => {
    Jobportal.find()
    .select('email')
    //.populate('jobportal', 'name')
    .exec()
    .then(docs => {
        const response = {
            count: docs.length,
            jobportal: docs.map(doc => {
                return {
                    fname: doc.fname,
                    lname: doc.lname,
                    email: doc.email,
                    gender: doc.gender,
                    isactive: doc.isactive,
                    regdate: doc.regdate,
                    id: doc.id,
                    request: {
                        type: 'GET',
                        url: 'http://localhost:3000/jobportal/' + doc.id
                    }
                }
            })
        };
        res.status(200).json(response);
        res.status(200).json(docs);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
}


exports.jobportal_create_jobportal =  (req, res, next) => {
     //instance of the jobportal and constructor
     const jobportal = new jobportal({
         id: new mongoose.Types.ObjectId(),
         fname: req.body.fname,
         lname: req.body.lname,
         email: req.body.email,
         gender: req.body.gender,
         isactive: req.body.isactive,
         regdate: req.body.regdate
     });
     jobportal.save().then(result => {
         console.log(result);
         res.status(201).json({
            message: 'Jobportal created successfully',
            createdJobportal: {
                fname: result.fname,
                lname: result.lname,
                email: result.email,
                gender: result.gender,
                isactive: result.isactive,
                regdate: result.regdate,
                id: result.id,
                request: {
                    type: 'GET',
                    url: 'http://localhost:3000/jobportal/' + result.id
                }
            }
         });
     })
     .catch(err => console.log(err));
     res.status(500).json({
         error: err
     });
 }

 exports.jobportal_get_jobportal = (req, res, next) => {
    const id = req.params.jobportalId;
    Jobportal.findById(id)
    .select('email')
    .exec().then(doc => {
        console.log(doc);
        if(doc){
           res.json(200).json({
            jobportal: doc,
               result:
               {
                   type: 'GET',
                   description: 'Get all job portal details',
                   url:'http://localhost:3000/jobportal'
               }
           });
        }
        else
        {
            res.status(404).json({message: 'No Record Found'});
        }
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({error: err});
    });
}

exports.jobportal_update_jobportal = (req, res, next) => {
    const id = req.params.jobportalId;
    const updateOps = {};
    for(const ops of req.body)
    {
        updateOps[ops.propName] = ops.value;
    }
    jobportal.update({ id: id}, {$set: updateOps })
    .exec()
    .then(result => {
        res.status(200).json({
            message: 'Job detail updated',
            result: {
                type: 'GET',
                url: 'http://localhost/jobportal:3000/' + id
            }
        });
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
   }


   exports.jobportal_delete =  (req, res, next) => {
    const id = req.params.jobportalId;
    Jobportal.remove({id: id}).exec().then(result => {
        res.status(200).json({
            message: 'Job detail deleted',
            request:{
                type: 'POST',
                url: 'http://localhost:3000/jobportal', 
                data: {email: 'String', isactive: 'String'}
            }
            
        });
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error: err
        });
    });
};

