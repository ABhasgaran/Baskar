const mongoose = require('mongoose');

const jobportalSchema = mongoose.Schema({
id: mongoose.Schema.Types.ObjectId,
fname: {type: String, required: true},
lname: {type: String, required: true},
email: {type: String, required: true},
gender: {type: String, required: true},
isactive: {type: String, required: true},
regdate: {type: String, required: true},
});

module.exports = mongoose.model('Jobportal', jobportalSchema);
