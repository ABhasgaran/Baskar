const express = require('express');
const router = express.Router();
const jobportal = require('../models/jobportal');
const mongoose = require('mongoose');
//const multer = require('multer');
const JobportalController = require('../controllers/jobportal');
const checkAuth = require('../middleware/check-auth');


const Jobportal =require("../models/jobportal");
router.get("/",  JobportalController.jobportal_get_all);
router.post("/",  JobportalController.jobportal_create_jobportal);
router.get("/", JobportalController.jobportal_get_jobportal);
router.patch('/:jobportalId', checkAuth, JobportalController.jobportal_update_jobportal);
router.delete('/:jobportalId', checkAuth, JobportalController.jobportal_delete);

module.exports = router;
