﻿import { Component } from 'angular2/core';
import { Http } from 'angular2/http';

@Component({
    selector: 'my-app',
    template: '{{title}}'
})
export class AppComponent {
    http: Http;
    public title;
    constructor(http: Http) {
        this.title = 'Loading list';
        this.http = http;
    }
}
