﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AngTest.Controllers
{
    [Route("[controller]")]
    public class DevicesController
    {
        [HttpGet]
        public object Get()
        {
            return new[] { new { id= "1", name = "Raspberry 1" },
new {id="2", name = "Raspberry 2" }};
        }
    }
}
