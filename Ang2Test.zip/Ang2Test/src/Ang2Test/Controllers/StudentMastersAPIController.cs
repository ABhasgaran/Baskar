using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Core1Angular2CRUDTest.Data;
using Core1Angular2CRUDTest.Models;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc.Cors.Internal;

namespace Core1Angular2CRUDTest.Controllers
{
    [EnableCors("AllowSpecificOrigin")]
    //[EnableCors("AllowAll")]
   
    [Produces("application/json")]
    [Route("http://localhost:50156/api/StudentMastersAPI")]
    public class StudentMastersApiController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentMastersApiController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: api/StudentMastersAPI
        [HttpGet]
        public IEnumerable<StudentMasters> GetStudentMasters()
        {
            return _context.StudentMasters;
        }


        
        // GET: api/StudentMastersAPI/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetStudentMasters([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            StudentMasters studentMasters = await _context.StudentMasters.SingleOrDefaultAsync(m => m.stdID == id);

            if (studentMasters == null)
            {
                return NotFound();
            }

            return Ok(studentMasters);
        }

        // PUT: api/StudentMastersAPI/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutStudentMasters([FromRoute] int id, [FromBody] StudentMasters studentMasters)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (id != studentMasters.stdID)
            {
                return BadRequest();
            }

            _context.Entry(studentMasters).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!StudentMastersExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/StudentMastersAPI
        [HttpPost]
        public async Task<IActionResult> PostStudentMasters([FromBody] StudentMasters studentMasters)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            _context.StudentMasters.Add(studentMasters);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (StudentMastersExists(studentMasters.stdID))
                {
                    return new StatusCodeResult(StatusCodes.Status409Conflict);
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("GetStudentMasters", new { id = studentMasters.stdID }, studentMasters);
        }

        // DELETE: api/StudentMastersAPI/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteStudentMasters([FromRoute] int id)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            StudentMasters studentMasters = await _context.StudentMasters.SingleOrDefaultAsync(m => m.stdID == id);
            if (studentMasters == null)
            {
                return NotFound();
            }

            _context.StudentMasters.Remove(studentMasters);
            await _context.SaveChangesAsync();

            return Ok(studentMasters);
        }

        private bool StudentMastersExists(int id)
        {
            return _context.StudentMasters.Any(e => e.stdID == id);
        }
    }
}