"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var core_1 = require('angular2/core');
var common_1 = require('angular2/common');
var http_1 = require('angular2/http');
var model_1 = require('./model');
require('rxjs/Rx');
var AppComponent = (function () {
    function AppComponent(http) {
        this.http = http;
        this.student = [];
        this.students = {};
        this.myName = "1234";
        this.getData();
    }
    AppComponent.prototype.getData = function () {
        var _this = this;
        this.http.get('http://localhost:50156/api/StudentMastersAPI')
            .map(function (responseData) {
            return responseData.json();
        })
            .map(function (student) {
            var result = [];
            if (student) {
                student.forEach(function (student) {
                    result.push(new model_1.StudentMasters(student.stdid, student.stdname, student.email, student.phone, student.address));
                });
            }
            return result;
        })
            .subscribe(function (res) { return _this.student = res; });
    };
    AppComponent.prototype.addStudentsDetails = function () {
        var headers = new http_1.Headers();
        headers.append('Content-Type', 'application/json; charset=utf-8');
        this.http.post('api/StudentMastersApi', JSON.stringify(this.students), { headers: headers }).subscribe();
        alert("Student Detail Inserted");
        this.getData();
    };
    AppComponent = __decorate([
        core_1.Component({
            selector: "my-app",
            directives: [common_1.NgFor],
            template: "     \n<table style=\"background-color:#FFFFFF; border: dashed 3px #6D7B8D; padding :5px;width :99%;table-layout:fixed;\" cellpadding=\"2\" cellspacing=\"2\">\n                    <tr style=\"height: 30px; background-color:#336699 ; color:#FFFFFF ;border: solid 1px #659EC7;\">\n                    \n                  <td>\n                      <h2>Insert User Details : </h2>\n                  </td>\n            </tr>\n        <tr>\n        <td>\n <table style=\"color:#9F000F;font-size:large\" cellpadding=\"4\" cellspacing=\"6\">\n <tr>\n     <td><b>User ID: </b> </td>\n    <td>\n      <input  [(ngModel)]=\"students.stdID\" value=\"0\" style=\"background-color:tan\" readonly>\n  </td>\n  <td><b>User Name: </b> </td>\n    <td>\n    <input  [(ngModel)]=\"students.stdName\" >\n  </td>\n</tr>\n <tr>\n     <td><b>Email: </b> </td>\n    <td>\n      <input  [(ngModel)]=\"students.email\" >\n  </td>\n  <td><b>Phone: </b> </td>\n    <td>\n    <input  [(ngModel)]=\"students.phone\" >\n  </td>\n</tr>\n<tr>\n     <td><b>Address: </b> </td>\n    <td>\n     <input  [(ngModel)]=\"students.address\" >\n  </td>\n  <td colspan=\"2\">\n<button (click)=addStudentsDetails() style=\"background-color:#334668;color:#FFFFFF;font-size:large;width:200px;\n                              border-color:#a2aabe;border-style:dashed;border-width:2px;\">Save</button>\n   </td>\n   </tr>\n   </table>\n </td>\n</tr>\n\n<tr><td>&nbsp; </td></tr>\n\n <tr>\n        <td>\n <table style=\"background-color:#FFFFFF; border solid 2px #6D7B8D; padding 5px;width 99%;table-layout:fixed;\" cellpadding=\"2\" cellspacing=\"2\">\n\n                                <tr style=\"height: 30px; background-color:#336699 ; color:#FFFFFF ;border: solid 1px #659EC7;\">\n                                    <td width=\"100\" align=\"center\">User ID</td>\n                                    <td width=\"240\" align=\"center\">User Name</td>\n                                    <td width=\"240\" align=\"center\">Email</td>\n                                    <td width=\"120\" align=\"center\">Phone</td>\n                                    <td width=\"340\" align=\"center\">Address</td>\n                                    \n\n                                </tr>\n                                <tbody *ngFor=\"let std of student\">\n                                    <tr>\n\n                                        <td align=\"center\" style=\"border: solid 1px #659EC7; padding: 5px;table-layout:fixed;\">\n                                            <span style=\"color:#9F000F\">{{std.stdID}}</span>\n                                        </td>\n\n                                        <td align=\"left\" style=\"border: solid 1px #659EC7; padding: 5px;table-layout:fixed;\">\n                                            <span style=\"color:#9F000F\">{{std.stdName}}</span>\n                                        </td>\n\n                                        <td align=\"left\" style=\"border: solid 1px #659EC7; padding: 5px;table-layout:fixed;\">\n                                            <span style=\"color:#9F000F\">{{std.email}}</span>\n                                        </td>\n\n                                        <td align=\"center\" style=\"border: solid 1px #659EC7; padding: 5px;table-layout:fixed;\">\n                                            <span style=\"color:#9F000F\">{{std.phone}}</span>\n                                        </td>\n\n                                        <td align=\"left\" style=\"border: solid 1px #659EC7; padding: 5px;table-layout:fixed;\">\n                                            <span style=\"color:#9F000F\">{{std.address}}</span>\n                                        </td>\n                                      \n                                    </tr>\n                                </tbody>\n                            </table>\n</td>\n</tr>\n</table>\n              ",
        }),
        core_1.Injectable(),
        __param(0, core_1.Inject(http_1.Http)), 
        __metadata('design:paramtypes', [http_1.Http])
    ], AppComponent);
    return AppComponent;
}());
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.js.map