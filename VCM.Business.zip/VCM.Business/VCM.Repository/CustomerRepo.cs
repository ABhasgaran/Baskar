﻿using System;
using System.Collections.Generic;
using System.Text;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Npgsql;
using VCM.Entities;
using VCM.RepositoryInterface;

namespace VCM.Repository
{
    public class CustomerRepo : BaseRepository, ICustomerRepo
    {
        BaseRepository Br = new BaseRepository();
    

        IList<Customer> ICustomerRepo.GetAllCustomer()
        {
            IList<Customer> customerList = SqlMapper.Query<Customer>((NpgsqlConnection)connection, "GETCUSTOMERS", commandType: System.Data.CommandType.StoredProcedure).ToList();
            return customerList;
            throw new NotImplementedException();
        }
    }
}
