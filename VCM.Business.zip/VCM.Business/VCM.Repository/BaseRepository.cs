﻿using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;

namespace VCM.Repository
{
    public class BaseRepository : IDisposable
    {
        protected IDbConnection connection;
        public static string dbObj = string.Empty;

        public BaseRepository()
        {
            ReadConfig();
        }

        public BaseRepository(string ApplicationInstance)
        {
            dbObj = ApplicationInstance;
            ReadConfig();
        }

        public string ReadConfig()
        {
            string connectionString = string.Empty;

            connectionString = @"Host=localhost;Database=vcm;Username=postgres;Password=Kermits;Port=5433;Pooling=true";
            connection = new NpgsqlConnection(connectionString);
            return connectionString;
        }

        private bool disposedValue = false;  

       
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //managed objects/state
                }
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            //throw new NotImplementedException();
        }
    }
}

