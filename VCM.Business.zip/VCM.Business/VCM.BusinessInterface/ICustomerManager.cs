﻿using System;
using System.Collections.Generic;
using System.Text;
using VCM.Entities;

namespace VCM.BusinessInterface
{
    public interface ICustomerManager
    {
        IList<Customer> GetAllCustomer();
    }

}
