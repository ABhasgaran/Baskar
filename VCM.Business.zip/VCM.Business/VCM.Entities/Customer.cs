﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VCM.Entities
{
    public class Customer
    {
        public string customerid
        {
            get;
            set;
        }
        public string firstname
        {
            get;
            set;
        }
        public string lastname
        {
            get;
            set;
        }
        public string email
        {
            get;
            set;
        }
        public DateTime createddate
        {
            get;
            set;
        }
    }
}
