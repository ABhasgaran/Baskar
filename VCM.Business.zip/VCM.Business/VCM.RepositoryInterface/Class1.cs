﻿using System;
using VCM.Entities
namespace VCM.RepositoryInterface
{
    public class Class1
    {
    }
}
