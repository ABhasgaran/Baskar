﻿using System;
using System.Collections.Generic;
using System.Text;
using VCM.Entities;

namespace VCM.RepositoryInterface
{
    public interface ICustomerRepo
    {
        IList<Customer> GetAllCustomer();
    }
}
