﻿using System;
using System.Collections.Generic;
using System.Text;
using CollRepositoryInterface;
using CollEntities;
using CollBusinessInterface;

namespace CollBusiness
{
    public class CustomerManager : ICustomerManager
    {
        ICustomerRepo customerRepoManager;
        public CustomerManager(ICustomerRepo customerRepo)
        {
            customerRepoManager = customerRepo;
        }


        IList<Customer> ICustomerManager.GetAllCustomer()
        {
            return customerRepoManager.GetAllCustomer();
            throw new NotImplementedException();
        }
    }

}
