﻿using System;
using System.Collections.Generic;
using System.Text;
using CollRepositoryInterface;
using CollEntities;
using CollBusinessInterface;

namespace CollBusiness
{
    public class UserManager : IUserManager
    {
        IUserRepository userRepository;
        public UserManager(IUserRepository userMgrRepository)
        {
            userRepository = userMgrRepository;
        }
        public bool AddUser(User user)
        {
            return userRepository.AddUser(user);
        }

        public bool DeleteUser(int userId)
        {
            return userRepository.DeleteUser(userId);
        }

        public IList<User> GetAllUser()
        {
            return userRepository.GetAllUser();
        }

        public User GetUserById(int userId)
        {
            return userRepository.GetUserById(userId);
        }

        public bool UpdateUser(User user)
        {
            return userRepository.UpdateUser(user);
        }
    }

}
