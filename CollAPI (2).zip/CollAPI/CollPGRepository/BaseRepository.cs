﻿using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using CollEntities;

namespace CollPGRepository
{
    public class BaseRepository : IDisposable
    {
        protected IDbConnection connection;
        public static string dbObj = string.Empty;

        public BaseRepository()
        {
            ReadConfig();
        }

        public BaseRepository(string ApplicationInstance)
        {
            dbObj = ApplicationInstance;
            ReadConfig();
        }

        public string ReadConfig()
        {
            string connectionString = string.Empty;

            connectionString = @"server=postgres;Password=Kermits;Host=localhost;Port=5433;Database=vcm;Pooling=true";
            connection = new SqlConnection(connectionString);
            return connectionString;
        }

        private bool disposedValue = false;  

        void IDisposable.Dispose()
        {
            throw new NotImplementedException();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //managed objects/state
                }
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            throw new NotImplementedException();
        }
    }
}

