﻿using System;
using System.Collections.Generic;
using System.Text;
using CollEntities;
using CollRepositoryInterface;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Npgsql;

namespace CollPGRepository
{
    class CustomerRepo : BaseRepository, ICustomerRepo
    {
        BaseRepository Br = new BaseRepository();
    

        IList<Customer> ICustomerRepo.GetAllCustomer()
        {
            IList<Customer> customerList = SqlMapper.Query<Customer>((NpgsqlConnection)connection, "GETCUSTOMERS", commandType: System.Data.CommandType.StoredProcedure).ToList();
            return customerList;
            throw new NotImplementedException();
        }
    }
}
