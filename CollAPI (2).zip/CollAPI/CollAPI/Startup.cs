﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using Microsoft.Extensions.Configuration.UserSecrets;
//using CollBusinessInterface;
//using CollRepositoryInterface;
//using CollBusiness;
//using CollRepository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.Authorization;
using Newtonsoft.Json;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using System.Security.Cryptography;
using Microsoft.Extensions.Options;
//using Swashbuckle.AspNetCore.SwaggerGen;
using Swashbuckle.AspNetCore.Swagger;
//using Swashbuckle.AspNetCore.SwaggerUI;
using Consul;
using System.Text;

namespace CollAPI
{
    public class Startup
    {
        //string ClientId;
        //string ClientSecret;

        //string _testSecret = null;
        //private string _noGetter;
        //private string[] _arr;
       
        //public string NoGetter {
        //    get { return _noGetter; } 
        //    set { _noGetter = value; }
               
        //}
        //public string NonPublicGetter { set { _noGetter = value; } }
        //public string this[int i]
        //{
        //    get { return _arr[i]; }
        //    set { _arr[i] = value; }
        //}
        
        
        public Startup(IHostingEnvironment env)
        {
           
            var builder = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)

                 .AddEnvironmentVariables();

            //if (env.IsDevelopment())
            //{
            //    builder.AddUserSecrets<Startup>();
            //}

            Configuration = builder.Build();
            //ClientId = Configuration["googleClientId"];
            //ClientSecret = Configuration["googleClientSecret"];
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public  void ConfigureServices(IServiceCollection services)
        {

            services.Configure<ConfigData>(Configuration);
            services.Configure<ConfigData>(async config => {
                using (var client = new ConsulClient(clientConfig => clientConfig.Address = new Uri("http://localhost:8500/")))
                {
                    var getPair = await client.KV.Get("serviceUrl");
                    if (getPair.Response != null)
                    {
                        var serviceUrl = Encoding.UTF8.GetString(getPair.Response.Value, 0, getPair.Response.Value.Length);
                        config.ServiceUrl = serviceUrl;
                    }
                }
            });

            //services.AddSwaggerGen(c =>
            //{
            //    c.SwaggerDoc("v1", new Info { Title = "My API", Version = "v1" });
            //});
        
         

            services.Configure<AppOptions>(options => Configuration.Bind(options));
            services.Configure<MySettings>(options => Configuration.GetSection("MySettings").Bind(options));
            //_testSecret = Configuration["MySecret"];
            services.AddIdentityServer()
                    .AddTemporarySigningCredential()
                    .AddInMemoryApiResources(Config.GetApiResources())
                    .AddInMemoryClients(Config.GetClients());

            //services.AddApplicationInsightsTelemetry(Configuration);

            //services.AddAuthorization(auth =>
            //{
            //    auth.AddPolicy("Bearer", new AuthorizationPolicyBuilder()
            //        .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme)
            //        .RequireAuthenticatedUser().Build());
            //});

           
            // Add framework services.
            services.AddMvc();
            services.AddOptions();
            services.Configure<ConfigData>(Configuration);
            //services.AddTransient<IUserManager, UserManager>();
            //services.AddTransient<IUserRepository, UserRepository>();
            services.AddLogging();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            //var result = string.IsNullOrEmpty(_testSecret) ? "Null" : "Not Null";
            //app.Run(async (context) =>
            //{
            //    await context.Response.WriteAsync($"Secret is {result}");
            //});

            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();
            loggerFactory.AddNLog();

            app.UseMvcWithDefaultRoute();
            //app.UseSwagger("/swagger/v1/swagger.json");
            //app.UseSwagger(c =>
            //{
            //    c.RouteTemplate = "/swagger/{documentName}/swagger.json";
            //});
            //app.UseSwaggerUI(c =>
            //{
            //    c.SwaggerEndpoint("/swagger/v1/swagger.json", "My API V1");
            //});
            //#region static files 
            //app.UseStaticFiles();
            //#endregion

            //#region Handle Exception 
            //app.UseExceptionHandler(appBuilder =>
            //{
            //    appBuilder.Use(async (context, next) =>
            //    {
            //        var error = context.Features[typeof(IExceptionHandlerFeature)] as IExceptionHandlerFeature;

            //        if (error != null && error.Error is SecurityTokenExpiredException)
            //        {
            //            context.Response.StatusCode = 401;
            //            context.Response.ContentType = "application/json";

            //            await context.Response.WriteAsync(JsonConvert.SerializeObject(new RequestResult
            //            {
            //                State = RequestState.NotAuth,
            //                Msg = "token expired"
            //            }));
            //        }
            //        else if (error != null && error.Error != null)
            //        {
            //            context.Response.StatusCode = 500;
            //            context.Response.ContentType = "application/json";
            //            await context.Response.WriteAsync(JsonConvert.SerializeObject(new RequestResult
            //            {
            //                State = RequestState.Failed,
            //                Msg = error.Error.Message
            //            }));
            //        }
            //        else await next();
            //    });
            //});
            //#endregion

            //#region UseJwtBearerAuthentication 
            //app.UseJwtBearerAuthentication(new JwtBearerOptions()
            //{
            //    TokenValidationParameters = new TokenValidationParameters()
            //    {
            //        IssuerSigningKey = TokenAuthOption.Key,
            //        ValidAudience = TokenAuthOption.Audience,
            //        ValidIssuer = TokenAuthOption.Issuer,
            //        ValidateIssuerSigningKey = true,
            //        ValidateLifetime = true,
            //        ClockSkew = TimeSpan.FromMinutes(0)
            //    }
            //});
            //#endregion
            app.UseMvc();
            //app.UseMvc(routes =>
            //{
            //    routes.MapRoute(
            //        name: "default",
            //        template: "{controller=Home}/{action=Index}/{id?}");
            //   // routes.MapSpaFallbackRoute("spa-fallback", new { controller = "Home", action = "Index" });
            //});
        }
    }
}
