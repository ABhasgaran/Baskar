﻿using System;
using Microphone;
using Microphone.Consul;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Mvc;

namespace CollAdmin
{
    class Program
    {
        static void Main(string[] args)
        {
            var options = new ConsulOptions();
            var loggerFactory = new LoggerFactory();
            var logger = loggerFactory.CreateLogger("logger");
            var provider = new ConsulProvider(loggerFactory, Options.Create(options));
            //Cluster.RegisterService(new Uri($"http://localhost:52437"), provider, "Orders", "v1", logger);
            //Console.ReadLine();
        }
     
    }
    //public class OrdersController : Controller
    //{
    //    //public string Get()
    //    //{
    //    //    return "WebApi Service";
    //    //}
    //}
}