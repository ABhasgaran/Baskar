﻿using System;

namespace CollBusinessInterface
{
    public class Class1
    {
    }
}
