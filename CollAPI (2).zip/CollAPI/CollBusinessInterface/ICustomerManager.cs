﻿using System;
using System.Collections.Generic;
using System.Text;
using CollEntities;

namespace CollBusinessInterface
{
    public interface ICustomerManager
    {
        IList<Customer> GetAllCustomer();
    }

}
