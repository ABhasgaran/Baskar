﻿using System;

namespace CollRepository
{
    public class Class1
    {
    }
}
