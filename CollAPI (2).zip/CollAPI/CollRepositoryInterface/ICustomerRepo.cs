﻿using System;
using System.Collections.Generic;
using System.Text;
using CollEntities;
namespace CollRepositoryInterface
{
    public interface ICustomerRepo
    {
        IList<Customer> GetAllCustomer();
    }
}
