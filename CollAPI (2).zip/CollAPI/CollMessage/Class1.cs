﻿using System;

namespace CollMessage
{
    public class Class1
    {
    }
}
