﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Swagger;
using System.IO;
using Microsoft.Extensions.PlatformAbstractions;
using Microsoft.AspNetCore.Mvc;
using SwashbuckleAspNetVersioningShim;
using Swashbuckle.AspNetCore.SwaggerGen;
using Swashbuckle.AspNetCore.SwaggerUI;

namespace WebApplication3
{
    public class Startup
    {
        public Startup(IHostingEnvironment env)
        {

            var builder = new ConfigurationBuilder()

                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
                .AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                .AddEnvironmentVariables();
                


            Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var pathToDoc = Configuration["Swagger:FileName"];
            // Add framework services.
            services.AddMvc();
            var mvcBuilder = services.AddMvc();

            // Adds versioning capabilities, defaulting to version 1.0 calls if available
            //services.AddApiVersioning(o =>
            //{
            //    o.AssumeDefaultVersionWhenUnspecified = true;
            //    o.DefaultApiVersion = new ApiVersion(1, 0);
            //});

            //services.AddSwaggerGen(c =>
            //{
            //    SwaggerVersioner.ConfigureSwaggerGen(c, mvcBuilder.PartManager);
            //});

            //services.AddSwaggerGen();
            //services.ConfigureSwaggerGen(options =>
            //{
            //    options.SwaggerDoc("v1",
            //        new Info
            //        {
            //            Title = "Geo Search API",
            //            Version = "v1",
            //            Description = "A simple api to search using geo location in Elasticsearch",
            //            TermsOfService = "None"
            //        }
            //     );
            //    var filePath = Path.Combine(PlatformServices.Default.Application.ApplicationBasePath, pathToDoc);
            //    options.IncludeXmlComments(filePath);
            //    options.DescribeAllEnumsAsStrings();
            //});
            //services.AddScoped<ISearchProvider, SearchProvider>();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory loggerFactory)
        {
            loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            loggerFactory.AddDebug();

            //    if (env.IsDevelopment())
            //    {
            //        app.UseDeveloperExceptionPage();
            //        app.UseBrowserLink();
            //    }
            //    else
            //    {
            //        app.UseExceptionHandler("/Home/Error");
            //    }
            //    app.UseMvc(routes =>
            //    {
            //        routes.MapRoute(
            //            name: "default",
            //            template: "{controller=Home}/{action=Index}/{id?}");
            //    });
            //    app.UseSwagger(c =>
            //    {
            //        c.PreSerializeFilters.Add((swagger, httpReq) => swagger.Host = httpReq.Host.Value);
            //    });

            //    app.UseSwaggerUi(c =>
            //    {
            //        c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1 Docs");
            //    });
            //app.UseSwagger();

            //// Let's enable SwaggerUI
            //app.UseSwaggerUI(c =>
            //{
            //    SwaggerVersioner.ConfigureSwaggerUI(c, partManager);
            //});
            app.UseMvc();
        }
    }
}
