"use strict";
var StudentMasters = (function () {
    function StudentMasters(StdID, StdName, Email, Phone, Address) {
        this.StdID = StdID;
        this.StdName = StdName;
        this.Email = Email;
        this.Phone = Phone;
        this.Address = Address;
    }
    return StudentMasters;
}());
exports.StudentMasters = StudentMasters;
//# sourceMappingURL=model.js.map