﻿using System;
using System.Collections.Generic;
using System.Text;
using Finance.Entities;

namespace Finance.RepositoryInterface
{
    public interface IGetAllPaymentsRepository
    {
        IList<GetAllPayments> GetAllPayments();
        IList<GetAllPayments> GetAllPaymentsByDetails(string AccountNumber, string ApplicationId);
    }
}
