﻿using System;
using System.Collections.Generic;
using System.Text;
using Finance.Entities;
namespace Finance.RepositoryInterface
{
    public interface IUserRepo
    {

        bool AddUser(Users user);
        bool UpdateUser(Users user);
        bool DeleteUser(string userId);
        IList<Users> GetAllUser();
        Users GetUserById(string userId);
    }
}
