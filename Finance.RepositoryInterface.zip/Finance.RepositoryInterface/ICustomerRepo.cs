﻿using System;
using System.Collections.Generic;
using System.Text;
using Finance.Entities;
namespace Finance.RepositoryInterface
{
    public interface ICustomerRepo
    {

        bool AddCustomer(Customer customer);
        bool UpdateCustomer(Customer customer);
        bool DeleteCustomer(string customerId);
        IList<Customer> GetAllCustomer();
        Customer GetCustomerById(string customerId);
    }
}
