﻿using System;
using System.Collections.Generic;
using System.Text;
using Finance.Entities;
using Finance.RepositoryInterface;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Finance.Repository
{
    class CustomerRepo : BaseRepository, ICustomerRepo
    {
        public bool AddCustomer(Customer customer)
        {


            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@firstName", customer.FirstName);
                parameters.Add("@lastName", customer.LastName);
                parameters.Add("@email", customer.Email);
                parameters.Add("@createtime", customer.CreateTime);
                SqlMapper.Execute(connection, "AddCustomer", param: parameters, transaction: null, commandTimeout: 30, commandType: System.Data.CommandType.StoredProcedure);
                return true;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
        }

        public bool DeleteCustomer(string customerId)
        {
            throw new NotImplementedException();
        }

        public IList<Customer> GetAllCustomer()
        {
           
            //IList<Users> customerList = SqlMapper.Query(connection, "UserDetailsProc",, transaction: null, buffered: true, commandTimeout: 30, commandType: System.Data.CommandType.StoredProcedure);
            throw new NotImplementedException();
        }

        public Customer GetCustomerById(string customerId)
        {
            throw new NotImplementedException();
        }

        public bool UpdateCustomer(Customer customer)
        {
            throw new NotImplementedException();
        }

    }
}
