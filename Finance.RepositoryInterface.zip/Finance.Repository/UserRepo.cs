﻿using System;
using System.Collections.Generic;
using System.Text;
using Finance.Entities;
using Finance.RepositoryInterface;
using Dapper;
using System.Data;
using System.Data.SqlClient;

namespace Finance.Repository
{
    class UserRepo : BaseRepository, IUserRepo
    {
        public bool AddUser(Users user)
        {


            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@FirstName", user.FirstName);
                parameters.Add("@LastName", user.LastName);
                parameters.Add("@Phone", user.Phone);
                parameters.Add("@Email", user.Email);
                parameters.Add("@ManagerName", user.ManagerName);
                parameters.Add("@ProjectName", user.ProjectName);
                parameters.Add("@Portfolio", user.Portfolio);
                SqlMapper.Execute(connection, "AddUser", param: parameters, transaction: null, commandTimeout: 30, commandType: System.Data.CommandType.StoredProcedure);
                return true;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
        }

        public bool DeleteUser(string userId)
        {
            throw new NotImplementedException();
        }

        public IList<Users> GetAllUser()
        {
           
            //IList<Users> customerList = SqlMapper.Query(connection, "UserDetailsProc",, transaction: null, buffered: true, commandTimeout: 30, commandType: System.Data.CommandType.StoredProcedure);
            throw new NotImplementedException();
        }

        public Users GetUserById(string userId)
        {
            throw new NotImplementedException();
        }

        public bool UpdateUser(Users user)
        {
            throw new NotImplementedException();
        }

      
    }
}
