﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static System.Data.CommandType;
using Finance.Entities;
using Finance.RepositoryInterface;
using System.Collections;
using Dapper;

namespace Finance.Repository
{
    public class GetAllPaymentsRepository : BaseRepository, IGetAllPaymentsRepository
    {
        BaseRepository Br = new BaseRepository("Collections");
        public IList<GetAllPayments> GetAllPayments()
        {
            IList<GetAllPayments> treatmentDetailsList = SqlMapper.Query<GetAllPayments>(connection, "GetAllPayments", commandType: StoredProcedure).ToList();
            return treatmentDetailsList;
            //throw new NotImplementedException();
        }

        public IList<GetAllPayments> GetAllPaymentsByDetails(string AccountNumber, string ApplicationId)
        {
            //try
            //{
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@AccountNumber", AccountNumber);
                parameters.Add("@ApplicationId", ApplicationId);

                IList<GetAllPayments> treatmentStatusList = SqlMapper.Query<GetAllPayments>(connection, "GetAllPayments", parameters, commandType: StoredProcedure).ToList();
                return treatmentStatusList;
            //}
            //catch(Exception ex)
            //{
            //    //throw new NotImplementedException();
            //}
           
        }
    }
   
}
