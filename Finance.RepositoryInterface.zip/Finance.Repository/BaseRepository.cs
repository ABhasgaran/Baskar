﻿using System;
using System.Data;
using System.Data.SqlClient;

namespace Finance.Repository
{
    public class BaseRepository : IDisposable
    {
        protected IDbConnection connection;
        public static string dbObj = string.Empty;

        public BaseRepository()
        {
            ReadConfig();
        }

        public BaseRepository(string ApplicationInstance)
        {
            dbObj = ApplicationInstance;
            ReadConfig();
        }

        public string ReadConfig()
        {
            string connectionString = string.Empty;

            switch (dbObj.ToLower().Trim())
            {
                case "collections":
                    connectionString = @"server=(localdb)\MSSQLlocaldb;Database=Collections; Trusted_Connection = True";
                    connection = new SqlConnection(connectionString);
                    break;
                case "finance":
                    connectionString = @"server=(localdb)\MSSQLlocaldb;Database=Collections; Trusted_Connection = True";
                    connection = new SqlConnection(connectionString);
                    break;
                default:
                    throw new InvalidOperationException("Connection Error");
            }
            return connectionString;
        }
        private bool disposedValue = false;  //redundant calls - identify

     
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //managed objects/state
                }
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            throw new NotImplementedException();
        }
    }
}
