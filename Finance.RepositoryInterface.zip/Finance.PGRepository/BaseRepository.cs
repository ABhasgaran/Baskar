﻿using System;
using System.Data;
using System.Data.SqlClient;
using Dapper;
using Npgsql;
using NpgsqlTypes;
using System.Collections.Generic;
using Finance.Entities;

namespace Finance.PGRepository
{
    public class BaseRepository : IDisposable
    {
        protected IDbConnection connection;
        public static string dbObj = string.Empty;

        public BaseRepository()
        {
            ReadConfig();
        }

        public BaseRepository(string ApplicationInstance)
        {
            dbObj = ApplicationInstance;
            ReadConfig();
        }

        public string ReadConfig()
        {
            string connectionString = string.Empty;

            connectionString = @"server=postgres;Password=Kermits;Host=localhost;Port=5433;Database=vcm;Pooling=true";
            connection = new SqlConnection(connectionString);
            return connectionString;
        }
        private bool disposedValue = false;  //redundant calls - identify


        //public Customer GetUserFromDb(int userId)
        //{
        //    //using (IDbConnection connection = new NpgsqlConnection(DbConnectionString))
        //    //{
        //    //    connection.Open();

        //    //    return connection.Query<Customer>(“proc_GetUserForId“, new
        //    //    {
        //    //        UserId = userId
        //    //    }, commandType: CommandType.StoredProcedure).Single();
        //    //}
        //}

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    //managed objects/state
                }
                disposedValue = true;
            }
        }
        public void Dispose()
        {
            Dispose(true);
            throw new NotImplementedException();
        }
    }
}
