﻿using System;
using System.Collections.Generic;
using System.Text;
using Finance.Entities;
using Finance.RepositoryInterface;
using Dapper;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using Npgsql;

namespace Finance.PGRepository.Repository
{
    class CustomerRepo : BaseRepository, ICustomerRepo
    {
        public bool AddCustomer(Customer customer)
        {

           
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@firstName", customer.FirstName);
                parameters.Add("@lastName", customer.LastName);
                parameters.Add("@email", customer.Email);
                parameters.Add("@createtime", customer.CreateTime);
                SqlMapper.Execute(connection, "AddCustomer", param: parameters, transaction: null, commandTimeout: 30, commandType: System.Data.CommandType.StoredProcedure);
                return true;
            }
            catch (Exception ex)
            {
                throw new NotImplementedException();
            }
        }

        public bool DeleteCustomer(string customerId)
        {
            throw new NotImplementedException();
        }

        public IList<Customer> GetAllCustomer()
        {
           
            IList<Customer> customerList = SqlMapper.Query<Customer>(connection, "GetUsers", commandType: CommandType.StoredProcedure).ToList();
            return customerList;
        }

        public Customer GetCustomerById(string customerId)
        {
            try
            {
                DynamicParameters parameters = new DynamicParameters();
                parameters.Add("@CustomerID", customerId);
                return SqlMapper.Query<Customer>((NpgsqlConnection)connection, "GetUsersById", parameters, commandType: CommandType.StoredProcedure).FirstOrDefault();
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        public bool UpdateCustomer(Customer customer)
        {
            DynamicParameters paramaters = new DynamicParameters();
            paramaters.Add("@firstname", customer.FirstName);
            paramaters.Add("@lastname", customer.LastName);
            paramaters.Add("@email", customer.Email);
            SqlMapper.Execute(connection, "UpdateCustomer", param: paramaters, commandType: CommandType.StoredProcedure);

            throw new NotImplementedException();
        }


        //public String GetResults(String aquery, int maxrecs, int offset)
        //{
        //    String result = "";
        //    NpgsqlCommand command;
        //    using (NpgsqlConnection conn = new NpgsqlConnection(
        //    Configuration.ConfigurationManager.ConnectionStrings["DSN"].ConnectionString))
        //    {
        //        conn.Open();

        //        command = new NpgsqlCommand("SELECT fnget_film_search_results(:search_criteria, :maxrecs, :offset)", conn);
        //        command.Parameters.Add(new NpgsqlParameter("search_criteria", System.Data.DbType.String, 300)).Value = aquery;
        //        command.Parameters.Add(new NpgsqlParameter("maxrecs", System.Data.DbType.Int16)).Value = maxrecs;
        //        command.Parameters.Add(new NpgsqlParameter("offset", System.Data.DbType.Int16)).Value = offset;

        //        try
        //        {
        //            result = (String)command.ExecuteScalar();
        //        }
        //        catch (Exception ex)
        //        {
        //            return "<error>ERROR " + ex.ToString() + "</error>";
        //        }
        //    }
        //    return result;
        //}
    }
}
