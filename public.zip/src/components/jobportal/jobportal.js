import React, { Component } from 'react';
import logo from './vz.svg';
import './users.css';

class Users extends Component {
  render() {
    return (
      <div className="App">
        <h2>Job Portal</h2>
      </div>
    );
  }
}

export default Users;
