import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Jobportal from './components/jobportal/jobportal';

class App extends Component {
  constructor() {
    super();
    this.state = {
      jobportal: []

    }
  }
  componentUserDetails(){
    fetch('/jobportal')
    .then(res => res.json())
    .then(jobportal => this.setState({jobportal}, () => console.log('User details', jobportal)
  ));
  } 
  render() {
    return (
      <div>
      <h2>Users</h2>
      <ul>
        {this.state.jobportal.map(jobportal => {
          <li key={jobportal.id}>{jobportal.fname} {jobportal.lname} </li>
        })}
        </ul>
        </div>
      // <div className="App">
      //   <header className="App-header">
      //     <img src={logo} className="App-logo" alt="logo" />
      //     <h1 className="App-title">VZ Job Portal</h1>
      //   </header>
      //   <Users />
      // </div>
    );
  }
}

export default App;
